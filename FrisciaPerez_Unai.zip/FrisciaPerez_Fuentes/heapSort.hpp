#include "heapSort.cpp"

void heapify(vector <int> &v, int n, int root);
void heapSort(vector <int> &v);

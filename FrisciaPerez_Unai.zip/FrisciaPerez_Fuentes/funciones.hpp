#include "ClaseTiempo.cpp"
#include "sistemaEcuaciones.cpp"
#include "funciones_comunes.cpp"
#include "determinantes.cpp"
#include "tiemposheapSort.cpp"
#include "determinanteIterativo.cpp"
#include "determianteRecursivo.cpp"


void ordenacionHeapSort();
void determinanteIterativo();
void determinanteRecursivo();
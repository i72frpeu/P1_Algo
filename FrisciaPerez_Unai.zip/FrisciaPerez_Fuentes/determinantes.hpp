#include <vector>
#include <cmath>


double resolverDeterminanteIterativo(vector <vector<double>> matriz, int n);
double resolverDeterminanteRecursivo(vector<vector<double>> &A, int n);